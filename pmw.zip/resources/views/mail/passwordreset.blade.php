<h1>Anda telah melakukan reset password sebagai berikut</h1>
<pre>
    NIM/NIP     : {{ $user->id }}
    Password    : {{ $password }}
</pre>