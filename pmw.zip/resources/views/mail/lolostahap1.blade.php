@extends('layouts.mail')

@section('content')
    <h4>Selamat, proposal dengan judul {{ $judul }} telah dinyatakan lolos pada tahap 1</h4>
@endsection