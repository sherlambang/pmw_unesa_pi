@extends('layouts.app')

@section('content')
    @include('part.permintaan_hak_akses')
    @include('part.linimasa')
@endsection