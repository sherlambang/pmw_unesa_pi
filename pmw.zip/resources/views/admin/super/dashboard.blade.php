@extends('layouts.app')

@section('brand')
    Dashboard
@endsection

@section('content')
    @include('part.linimasa')
@endsection