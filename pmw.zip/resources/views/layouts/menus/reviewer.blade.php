<li {{ Route::currentRouteName() === 'daftar.proposal.reviewer' ? 'class=active' : ''}}>
    <a href="{{ route('daftar.proposal.reviewer') }}">
        <i class="material-icons">book</i>
        <p>Daftar Proposal</p>
    </a>
</li>
