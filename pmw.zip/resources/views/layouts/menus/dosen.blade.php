<li {{ Route::currentRouteName() === 'bimbingan' ? 'class=active' : '' }}>
    <a href="{{ route('bimbingan') }}">
        <i class="material-icons">library_books</i>
        <p>Bimbingan</p>
    </a>
</li>
