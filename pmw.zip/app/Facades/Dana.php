<?php

namespace PMW\Facades;

use Illuminate\Support\Facades\Facade;

class Dana extends Facade
{

    public static function getFacadeAccessor()
    {
        return 'Dana';
    }

}
