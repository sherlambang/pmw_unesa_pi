<?php

namespace PMW\Support;


class RequestStatus
{

    const REQUESTING = 'Requesting';

    const APPROVED = 'Approved';

    const REJECTED = 'Rejected';

}