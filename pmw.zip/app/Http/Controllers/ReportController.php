<?php

namespace PMW\Http\Controllers;

use Illuminate\Http\Request;

class ReportController extends Controller
{
    //
}
